c Common for computing and passing the station-station covariance
      parameter (maxsta=200,maxevt=40)
      character*4 sta
      common /SSRR/ns,ne,elatrd(maxevt),elonrd(maxevt)
     :,rr(maxsta,maxsta),vel,sta(maxsta)
c
