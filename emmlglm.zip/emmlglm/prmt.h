C for mlglm7 (no inter-event correlation corretion, perry)
C	parameter (nsmax=200,nemax=300,nqmax=500)
C for mlglm6 (with correlation correction, perry)
C  	parameter (nsmax=100,nemax=100,nqmax=200)
C for mlglm6 (with correlation correction, with -ffpa, ra)
C 	parameter (nsmax=130,nemax=100,nqmax=230)
C for mlglm8,9,10 (with correlation correction, perry)
  	parameter (nsmax=200,nemax=2500,nqmax=200,nrmax=20)
C
C nsmax max stations
C
C nemax max events
C
C nrmax max regions
C
C nqmax only used for inter-event correlation
C 
C
